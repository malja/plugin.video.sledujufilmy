from resources.lib.scrappers.sledujufilmy import SledujuFilmy

__ALL__ = [SledujuFilmy]
